
package com.mycompany.jpaprueba.logica;

import com.mycompany.jpaprueba.persistencia.ControladoraPersistemcia;


public class Controladora {
    //instanciamos para usar la clase, pero la clase no tiene métodos, tiene otra instancia
    ControladoraPersistemcia controlpersi = new ControladoraPersistemcia();
    
    //creamos el método para usar un método de ControladoraPersistemcia, que no tine métodos
    //alu es el objeto que ya se creo en la gráfica
    public void crearUsuario(Usuario usua){
        controlpersi.crearUsuario(usua);
    }
}
