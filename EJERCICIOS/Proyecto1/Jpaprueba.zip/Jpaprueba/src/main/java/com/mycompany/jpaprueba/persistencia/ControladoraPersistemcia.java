
package com.mycompany.jpaprueba.persistencia;

import com.mycompany.jpaprueba.logica.Usuario;


public class ControladoraPersistemcia {
    UsuarioJpaController usuaJpa = new UsuarioJpaController();

    public void crearUsuario(Usuario usua) {
        usuaJpa.create(usua);
    }
}
