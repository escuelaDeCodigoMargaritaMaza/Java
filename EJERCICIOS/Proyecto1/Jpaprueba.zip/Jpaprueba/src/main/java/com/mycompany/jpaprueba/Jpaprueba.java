

package com.mycompany.jpaprueba;

import com.mycompany.jpaprueba.logica.Controladora;
import com.mycompany.jpaprueba.logica.Usuario;
import java.util.Date;


public class Jpaprueba {

    public static void main(String[] args) {
        //instanciamos a controladora
        Controladora control = new Controladora();
        Usuario usua3 = new Usuario(4,"david","santillan",new Date());
        Usuario usua4 = new Usuario(5,"david","santillan",new Date());
        control.crearUsuario(usua3);
        control.crearUsuario(usua4);
    }
}
