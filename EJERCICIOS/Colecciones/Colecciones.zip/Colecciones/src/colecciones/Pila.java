
package colecciones;

import java.util.Stack;


public class Pila {
    public void pila(){
       Stack <String> pila = new Stack <>();
    
       //metodo push
       pila.push("python");  //los va a apilando
       pila.push("java");
       pila.push("c++");
       pila.push("ruby");
       
       System.out.println("pila" + pila);
       
       //metodo pop
       pila.pop(); //va por el último elemento en entrar
       System.out.println("pila "+ pila);
        
       //elemento en la parte superior
       System.out.println("elemento en la parte superior: " + pila.peek());
        
        //busca en la lista
       System.out.println("posición de java: " + pila.search("java")); 
        
        //revisar si la pila esta vacia
       boolean res = pila.empty();//meter en variable para poder volvera usar
        System.out.println("pila vacia? " + res);
    }
   
}
