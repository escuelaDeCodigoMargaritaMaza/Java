
package colecciones;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;


public class Colecciones {

 
    public static void main(String[] args) {
      //1.de forma interna  
       /*LinkedList<String> linkedlist = new LinkedList<>();
        
        linkedlist.add("hola");
        
        System.out.println(linkedlist.get(0)); */
        
        
      //2.trayendo de clase externa  
      Linked clase1 = new Linked();
      clase1.linked();
      
      //3.dentro pero abajo
       Linked1 clase2 = new Linked1();
       clase2.linked();
       
       
       //traigo la clase array
       Arraylist array = new Arraylist();
       array.arraylist();
       
      //pila
      Pila pil =new Pila();
      pil.pila();
       
    }
    
}




//3.clase externa
class Linked1{
        public void linked(){
        LinkedList<String> linkedlist = new LinkedList<>();
        
        linkedlist.add("hola");
        
        System.out.println(linkedlist.get(0));
    }
}
