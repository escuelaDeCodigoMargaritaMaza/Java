
package colecciones;

import java.util.LinkedList;
import java.util.Queue;

public class Cola {
    public void queue(){
        Queue <Persona> cola1 = new LinkedList <Persona>();
    }
}
