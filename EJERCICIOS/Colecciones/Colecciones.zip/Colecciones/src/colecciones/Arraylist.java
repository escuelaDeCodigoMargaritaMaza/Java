
package colecciones;

import java.util.ArrayList;
import java.util.List;


public class Arraylist {
    public void arraylist(){
        //4.ArrayList
       List<Persona> lista = new ArrayList<>(); //se importa los util List y Arraylist
       lista.add(new Persona(1,"david",45)); //creamos la persona y se agrega a la lista
       lista.add(new Persona(2,"miguel",45));
       lista.add(new Persona(3,"juan",45));
       lista.add(new Persona(4,"jose",45));
     //no tienen nombre los objetos solo son agregados a la lista
    //recorrido con foreach
       for(Persona per:lista){
            System.out.println(per.getNombre());
       }
    }
}
