
package colecciones;

import java.util.LinkedList;
import java.util.List;

public class Linked {
        public void linked(){
        LinkedList<String> linkedlist = new LinkedList<>();
        
        linkedlist.add("hola");
        linkedlist.add("hi");
        linkedlist.add("bye");
        linkedlist.add("salute");
        linkedlist.add("hello");
        linkedlist.add("adios");
        System.out.println(linkedlist);
        System.out.println(linkedlist.get(0));
        
        linkedlist.set(0,"adios");
        System.out.println(linkedlist);
        
        linkedlist.remove(0);//a diferencia de array podemos borrar por el valor
        linkedlist.remove("bye");
        System.out.println(linkedlist);
        
        
       //creamos el linkedlist de objeto
       
       LinkedList<Persona> lista1 = new LinkedList<>();
       
       lista1.add(new Persona(2,"miguel",45));
       lista1.add(new Persona(3,"juan",45));
       lista1.add(new Persona(4,"jose",45));
       //a diferencia de Arraylist podemos darle la posicion
       lista1.add(0,new Persona(4,"jose",45));
       for(Persona per:lista1){
            System.out.println(per.getNombre());
       }
       
       //otros métodos
       //tamaño
      System.out.println("Tamaño de la lista: "+ lista1.size());
      
      //ver toda la lista con el metodo toString
       System.out.println(lista1.toString());
      
       //ultimo elemento de la lista
      System.out.println("ultimo elemento de la lista" + lista1.getLast());
        
      //primer elemento de la lista
      System.out.println("primer elemento de la lista"+lista1.getFirst());
      
       //preguntar si esta vacia
      System.out.println("esta vacia la lista1? "+lista1.isEmpty());
    }
}
