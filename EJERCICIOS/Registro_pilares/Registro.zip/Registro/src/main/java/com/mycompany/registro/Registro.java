

package com.mycompany.registro;

import com.mycompany.registro.igu.Principal;


public class Registro {

    public static void main(String[] args) {
        Principal ventana = new Principal();
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
    }
}
